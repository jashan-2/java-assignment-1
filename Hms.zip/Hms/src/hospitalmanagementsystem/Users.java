
package hospitalmanagementsystem;


public class Users {

    public static String[] user = {"Admin Portal", "Doctor Portal", "Patient Portal"};

}
